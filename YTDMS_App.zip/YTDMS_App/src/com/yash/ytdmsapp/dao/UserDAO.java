package com.yash.ytdmsapp.dao;

import java.util.List;

import com.yash.ytdmsapp.domain.User;
/**
 * This UserDAO is responsible for all the CRUD operations within system.
 * @author rajpal.dodiya
 *
 */
public interface UserDAO {
	
	int TRAINING_MANAGER=1;
	int TRAINER=2;
	int ADMIN=3;
	int ACTIVE_USER=1;
	int BLOCKED_USER=2;
	/**
	 * This save method will take a User object and will save the
	 * information of corresponding User
	 * @param user whose details to be saved.
	 */
	void save(User user);

	/**
	 * This findAll method will return a list of all the available users from database.
	 * @return list of all the available users if no user exists then null
	 */
	List<User> findAll();
	
	/**
	 * This update method will update the user details accordingly
	 * @param user to be updated.
	 */
	void update(User user);
	
	/**
	 * This delete method will delete the user according to the information provided in
	 * User object
	 * @param user to be deleted.
	 */
	void delete(User user);
}
