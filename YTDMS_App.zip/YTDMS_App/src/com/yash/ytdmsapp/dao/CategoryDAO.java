package com.yash.ytdmsapp.dao;

import java.util.List;

import com.yash.ytdmsapp.domain.Category;
/**
 * This CategoryDAO is responsible for all the CRUD operations within system.
 * @author rajpal.dodiya
 *
 */
public interface CategoryDAO {
	
	/**
	 * This save method will take a Category object and will save the
	 * information of corresponding Category
	 * @param category whose details to be saved.
	 */
	void save(Category category);

	/**
	 * This findAll method will return a list of all the available categorys from database.
	 * @return list of all the available categorys if no category exists then null
	 */
	List<Category> findAll();
	
	/**
	 * This update method will update the category details accordingly
	 * @param category to be updated.
	 */
	void update(Category category);
	
	/**
	 * This delete method will delete the category according to the information provided in
	 * Category object
	 * @param category to be deleted.
	 */
	void delete(Category category);
	
	/**
	 * This delete method will delete the category according to the information provided in
	 * @param category to be deleted.
	 * @param categoryId
	 */
	public void delete(int categoryId);

	
}

