package com.yash.ytdmsapp.domain;
/**
 * This component is data traveller which will be used on different layers.
 * @author rajpal.dodiya
 *
 */
public class User {
	/**
	 * Id of user 
	 * PK
	 */
	private int id;
	/**
	 * Name of user must be less then equal to 20 characters
	 */
	private String name;
	/**
	 * Email of user must be less then equal to 20 characters
	 */
	private String email;
	/**
	 * Login id of user which is going to be used for authentication purpose
	 */
	private String loginId;
	/**
	 * Password of user must be less then or equal to 20 characters
	 */
	private String password;
	/**
	 * status of user
	 * only two status available that is
	 * active and
	 * blocked
	 * by default it is active
	 */
	private int status;
	/**
	 * role of user
	 * only three roles are avialable right now
	 * that is
	 * trainer manager
	 * trainer
	 * and admin
	 * by default it is trainer
	 */
	private int role;

	//getters and setters
	public int getRole() {
		return this.role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
}
