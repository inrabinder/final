package com.yash.ytdmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class EditCategoryHelperController
 */
@WebServlet("/EditCategoryHelperController")
public class EditCategoryHelperController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CategoryService categoryService;
	public EditCategoryHelperController() {
	categoryService=new CategoryServiceImpl();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Category category=new Category();
		category.setName(request.getParameter("name"));
		category.setId(Integer.parseInt(request.getParameter("id")));
		category.setDescription(request.getParameter("description"));
		categoryService.editCategory(category,1);
		getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request, response);
		
	}

}
