package com.yash.ytdmsapp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/SearchController")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CategoryService categoryService;   
    
    public SearchController() {
        super();
        categoryService=new CategoryServiceImpl();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Category> categories=categoryService.searchByCategoryName(request.getParameter("search"));
		HttpSession httpSession=request.getSession();
		httpSession.setAttribute("categories",categories);
		response.sendRedirect("index.jsp");
	}

	

}
