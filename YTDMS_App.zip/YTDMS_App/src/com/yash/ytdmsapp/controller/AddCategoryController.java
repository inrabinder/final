package com.yash.ytdmsapp.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdmsapp.domain.Category;
import com.yash.ytdmsapp.service.CategoryService;
import com.yash.ytdmsapp.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class AddCategoryController
 */
@WebServlet("/AddCategoryController")
public class AddCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private CategoryService categoryService=null;   
   
    public AddCategoryController() {
        super();
        categoryService=new CategoryServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 Category category=new Category();
	 category.setName(request.getParameter("name"));
	 category.setDescription(request.getParameter("description"));
	 category.setStatus(1);
	 HttpSession httpSession=request.getSession();
	 category.setUserId((int)httpSession.getAttribute("loggedInUserId"));
	 categoryService.addCategory(category);
	 getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request, response);
	}

	

}
