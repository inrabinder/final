package com.yash.ytdmsapp.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBUtil {

	private static String driverName = "com.mysql.jdbc.Driver";
	private static String url="jdbc:mysql://localhost/ytdmsdb";
	private static String user="root";
	private static String password="root";
	private static Connection connection;
	static {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static Connection connect() throws SQLException
	{
		connection=DriverManager.getConnection(url, user, password);
		return connection;
	}
	
	public PreparedStatement prepareStatement(String sql)
	{ 
		PreparedStatement preparedStatement=null;
		try {
			preparedStatement=connect().prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	return preparedStatement;
	}
	
	public void closeConnection()
	{
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
