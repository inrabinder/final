package com.yash.ytdmsapp.service;

import com.yash.ytdmsapp.domain.User;
import com.yash.ytdmsapp.exception.UserException;
/**
 * This UserService will contain all the business logics related to User
 * @author rajpal.dodiya
 *
 */
public interface UserService {
	/**
	 * This registerUser method will register a user with the system.
	 * @param user to be registered.
	 * @throws UserException if user already exists with same credentials.
	 */
void registerUser(User user)throws UserException;
	/**
	 * This authenticateUser will authenticate the user 
	 * @param loginId of user for verification purpose
	 * @param password of user for verification purpose
	 * @return 
	 */
User authenticateUser(String loginId,String password);
}
